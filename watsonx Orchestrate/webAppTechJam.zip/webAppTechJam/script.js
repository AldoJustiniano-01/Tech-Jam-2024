document.addEventListener("DOMContentLoaded", function() {
    const validUsername = "admin";
    const validPassword = "password123";
    
    const loginSection = document.getElementById('login-section');
    const loginForm = document.getElementById('login-form');
    const wrapper = document.querySelector('.wrapper');
    const sidebar = document.getElementById("sidebar");
    const logoutBtn = document.querySelector('.sidebar-footer a');

    const links = document.querySelectorAll(".sidebar-link");
    const sections = document.querySelectorAll(".content-section");

    // Função para mostrar uma seção específica e esconder as outras
    function showSection(sectionId) {
        sections.forEach(section => section.style.display = "none");
        document.getElementById(sectionId).style.display = "block";
    }

    // Verifica se o usuário já está logado
    if (localStorage.getItem('loggedIn') === 'true') {
        loginSection.style.display = 'none';
        wrapper.style.display = 'flex'; // Alinha corretamente o wrapper com o sidebar
        sidebar.classList.add('expand'); // Expande o sidebar por padrão
    } else {
        wrapper.style.display = 'none';
        loginSection.style.display = 'flex';
    }

    loginForm.addEventListener('submit', function(event) {
        event.preventDefault();
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
    
        // Limpar mensagens de alerta anteriores
        document.getElementById('alert-container').innerHTML = '';
    
        if (username === validUsername && password === validPassword) {
            localStorage.setItem('loggedIn', 'true');
            loginSection.style.display = 'none';
            wrapper.style.display = 'flex'; // Alinha corretamente o wrapper com o sidebar
            sidebar.classList.add('expand'); // Expande o sidebar após o login

            // Verifica a seção ativa e carrega os dados adequados
            const activeSection = localStorage.getItem('activeSection') || 'task-content';
            showSection(activeSection);
        } else {
            // Criar a mensagem de alerta Bootstrap
            const alertDiv = document.createElement('div');
            alertDiv.className = 'alert alert-danger alert-dismissible fade show';
            alertDiv.role = 'alert';
            alertDiv.innerHTML = `
                Invalid credentials. Please try again.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            `;
            // Inserir a mensagem de alerta no contêiner
            document.getElementById('alert-container').appendChild(alertDiv);
    
            // Fechar o alerta após 5 segundos
            setTimeout(() => {
                const alert = new bootstrap.Alert(alertDiv);
                alert.close();
            }, 5000); // 5000 milissegundos = 5 segundos
        }
    });
    
    const toggleBtn = document.querySelector(".toggle-btn");

    // Função para expandir/contrair a barra lateral
    toggleBtn.addEventListener("click", function() {
        sidebar.classList.toggle("expand");
    });

    // Event Listener para o botão de logout
    logoutBtn.addEventListener('click', function(event) {
        event.preventDefault();
        localStorage.removeItem('loggedIn'); // Remove apenas o estado de login
        loginSection.style.display = 'flex'; // Exibe a tela de login
        wrapper.style.display = 'none'; // Esconde o conteúdo principal
    });

    // Função para mostrar um alerta Bootstrap
    function showAlert(message, type = 'success', containerId = 'alert-container') {
        const alertContainer = document.getElementById(containerId);
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
        alertDiv.role = 'alert';
        alertDiv.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        `;
        alertContainer.appendChild(alertDiv);
    
        setTimeout(() => {
            const alertInstance = new bootstrap.Alert(alertDiv);
            alertInstance.close();
        }, 3000);
    }

    // Função para adicionar uma nova tarefa à lista de tarefas
    function addTask(taskName, status, responsible, dueDate) {
        let tasks = JSON.parse(localStorage.getItem('tasks')) || [];
        tasks.push({ taskName, status, responsible, dueDate });
        localStorage.setItem('tasks', JSON.stringify(tasks));
        loadTasks();
    }

// Função para carregar as tarefas na sessão Task
function loadTasks() {
    const tableBody = document.querySelector('#task-content tbody');
    tableBody.innerHTML = '';
    
    // Limpar a tabela antes de carregar os dados

    let tasks = JSON.parse(localStorage.getItem('tasks')) || [];

    tasks.forEach((task, index) => {
        let row = document.createElement('tr');
        row.innerHTML = `
            <td>${index + 1}</td>
            <td>${task.taskName}</td>
            <td><span class="badge ${getStatusBadge(task.status)}">${task.status}</span></td>
            <td>${task.responsible}</td>
            <td>${task.dueDate}</td>
            <td>
                <button class="btn btn-sm btn-primary" onclick="editTask(${index})">Edit</button>
                <button class="btn btn-sm btn-danger" onclick="deleteTask(${index})">Delete</button>
            </td>
        `;
        tableBody.appendChild(row);
    });
}

// Função para deletar uma tarefa
function deleteTask(index) {
    let tasks = JSON.parse(localStorage.getItem('tasks')) || [];
    tasks.splice(index, 1); // Remove a tarefa do array
    localStorage.setItem('tasks', JSON.stringify(tasks)); // Atualiza o localStorage
    loadTasks(); // Recarrega a lista de tarefas
    location.reload(); // Recarrega a página
}


    // Função para definir a cor do badge de status
    function getStatusBadge(status) {
        switch (status) {
            case 'In Progress':
                return 'bg-warning';
            case 'Completed':
                return 'bg-success';
            case 'Overdue':
                return 'bg-danger';
            case 'Pending':
                return 'bg-info';
            default:
                return 'bg-secondary';
        }
    }

    // Função para salvar dados do formulário Auto no Local Storage
    function handleAutoFormSubmission(event) {
        event.preventDefault();

        const formData = {
            name: document.getElementById('name').value,
            address: document.getElementById('address').value,
            city: document.getElementById('city').value,
            state: document.getElementById('state').value,
            zipcode: document.getElementById('zipcode').value,
            maritalStatus: document.getElementById('maritalStatus').value,
            cgcCpf: document.getElementById('cgc-cpf').value,
            licenceDrive: document.getElementById('licenceDrive').value,
            age: document.getElementById('age').value,
            sex: document.getElementById('sex').value,
            commercialUse: document.getElementById('commercialUse').value
        };

        // Salvar os dados no Local Storage
        let storedData = JSON.parse(localStorage.getItem('autoData')) || [];
        storedData.push(formData);
        localStorage.setItem('autoData', JSON.stringify(storedData));

        // Adicionar uma tarefa relacionada na seção "Task"
        addTask(`Process Auto Request for ${formData.name}`, 'In Progress', formData.name, new Date().toLocaleDateString());

        // Mostrar o alerta de sucesso
        showAlert('Dados salvos com sucesso!', 'success', 'auto-alert-container'); 

        event.target.reset(); // Opcional: Resetar o formulário após salvar

        // Armazena no Local Storage que a seção "auto-content" deve ser ativada após o reload
        localStorage.setItem('activeSection', 'auto-content');

        // Recarregar a tabela após o envio do formulário
        loadTableData();
    }

    // Função para salvar dados do formulário Bank Credit no Local Storage
    function handleCreditFormSubmission(event) {
        event.preventDefault();

        const creditData = {
            name: document.getElementById('applicantName').value,
            cpf: document.getElementById('applicantCpf').value,
            creditAmount: document.getElementById('creditAmount').value,
            monthlyIncome: document.getElementById('monthlyIncome').value,
            creditPurpose: document.getElementById('creditPurpose').value
        };

        // Salvar os dados no Local Storage
        let storedCreditData = JSON.parse(localStorage.getItem('creditData')) || [];
        storedCreditData.push(creditData);
        localStorage.setItem('creditData', JSON.stringify(storedCreditData));

        // Adicionar uma tarefa relacionada na seção "Task"
        addTask(`Process Credit Request for ${creditData.name}`, 'Pending', creditData.name, new Date().toLocaleDateString());

        // Mostrar alerta de sucesso
        showAlert('Solicitação de crédito enviada com sucesso!', 'success', 'bank-alert-container');

        event.target.reset(); // Opcional: Resetar o formulário após salvar

        // Recarregar a tabela de solicitações de crédito
        loadCreditRequests();
    }

    // Função para carregar os dados do Local Storage e exibi-los na tabela de Auto
    function loadTableData() {
        const tableBody = document.querySelector('#auto-content tbody');
        tableBody.innerHTML = ''; // Limpar a tabela antes de carregar os dados

        let storedData = JSON.parse(localStorage.getItem('autoData')) || [];

        storedData.forEach((data, index) => {
            let row = document.createElement('tr');
            row.innerHTML = `
                <td>${index + 1}</td>
                <td>${data.name}</td>
                <td>${data.address}</td>
                <td>${data.city}</td>
                <td>${data.state}</td>
                <td>${data.zipcode}</td>
                <td>${data.maritalStatus}</td>
                <td>${data.cgcCpf}</td>
                <td>${data.licenceDrive}</td>
                <td>${data.age}</td>
                <td>${data.sex}</td>
                <td>${data.commercialUse}</td>
            `;
            tableBody.appendChild(row);
        });
    }

    // Função para carregar as solicitações de crédito do Local Storage e exibi-las na tabela
    function loadCreditRequests() {
        const tableBody = document.getElementById('credit-requests');
        tableBody.innerHTML = ''; // Limpar a tabela antes de carregar os dados

        let storedCreditData = JSON.parse(localStorage.getItem('creditData')) || [];

        storedCreditData.forEach((data, index) => {
            let row = document.createElement('tr');
            row.innerHTML = `
                <td>${index + 1}</td>
                <td>${data.name}</td>
                <td>${data.cpf}</td>
                <td>${data.creditAmount}</td>
                <td>${data.monthlyIncome}</td>
                <td>${data.creditPurpose}</td>
            `;
            tableBody.appendChild(row);
        });
    }

    // Verifica se há uma seção ativa armazenada no Local Storage
    const activeSection = localStorage.getItem('activeSection');
    if (activeSection) {
        showSection(activeSection);
        if (activeSection === 'auto-content') {
            loadTableData();
        } else if (activeSection === 'bank-content') {
            loadCreditRequests();
        } else if (activeSection === 'task-content') {
            loadTasks(); // Carregar as tarefas para Task content
        }
    } else {
        // Exibir a primeira seção por padrão, se nenhuma estiver armazenada
        showSection('task-content');
        loadTasks();
    }

    // Configurar navegação para mudar de seção e armazenar a seção ativa
    links.forEach(link => {
        link.addEventListener('click', function(event) {
            event.preventDefault();
            const sectionId = link.id.replace('-link', '-content');
            showSection(sectionId);
            localStorage.setItem('activeSection', sectionId); // Armazenar seção ativa
            if (sectionId === 'auto-content') {
                loadTableData();
            } else if (sectionId === 'bank-content') {
                loadCreditRequests();
            } else if (sectionId === 'task-content') {
                loadTasks();
            }
        });
    });

    // Associar as funções de submissão dos formulários apenas uma vez
    const autoForm = document.querySelector('#auto-content form');
    if (autoForm) {
        autoForm.addEventListener('submit', handleAutoFormSubmission);
    }

    const creditForm = document.getElementById('credit-form');
    if (creditForm) {
        creditForm.addEventListener('submit', handleCreditFormSubmission);
    }

    // Carregar dados quando a página é carregada
    loadTasks();
    loadTableData();
    loadCreditRequests();
});

// Função para excluir uma tarefa
function deleteTask(index) {
    let tasks = JSON.parse(localStorage.getItem('tasks')) || [];
    tasks.splice(index, 1); // Remove a tarefa do array
    localStorage.setItem('tasks', JSON.stringify(tasks));
    loadTasks(); // Recarrega a tabela de tarefas
}

// Função para editar uma tarefa
function editTask(index) {
    let tasks = JSON.parse(localStorage.getItem('tasks')) || [];
    let task = tasks[index];

    // Preencher o formulário de edição com os dados da tarefa
    document.getElementById('task-name').value = task.taskName;
    document.getElementById('task-status').value = task.status;
    document.getElementById('task-responsible').value = task.responsible;
    document.getElementById('task-due-date').value = task.dueDate;

    // Mostrar o formulário de edição
    document.getElementById('edit-task-form').style.display = 'block';

    // Adicionar um EventListener ao botão de salvar
    document.getElementById('save-task-btn').onclick = function() {
        task.taskName = document.getElementById('task-name').value;
        task.status = document.getElementById('task-status').value;
        task.responsible = document.getElementById('task-responsible').value;
        task.dueDate = document.getElementById('task-due-date').value;

        // Salvar as alterações
        tasks[index] = task;
        localStorage.setItem('tasks', JSON.stringify(tasks));
        
        // Ocultar o formulário de edição e recarregar a lista de tarefas
        document.getElementById('edit-task-form').style.display = 'none';
        loadTasks();

        // Exibir alerta de sucesso
        showAlert('Task updated successfully!', 'success', 'alert-container');
    };
}
